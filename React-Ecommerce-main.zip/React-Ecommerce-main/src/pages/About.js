import React from 'react'
import HeroSection from '../components/HeroSection'

const data = {
  name: 'FlixZone Ecommerce',
}

const About = () => {
  return <HeroSection name={data.name} />
}

export default About
