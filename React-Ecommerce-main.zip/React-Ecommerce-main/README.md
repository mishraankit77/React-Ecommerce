# React E-commerce

E-commerce Website made using React. For State Management Context API is used with useReducer hook. Item data is gathered using API with the help of Axios.

---

![React-Ecommerce](https://github.com/Ashish-Bind/React-Ecommerce/assets/121487855/3a315e83-78b1-40d5-a15b-2380067cf067)


---

[Website Link](https://react-ecommerce-1blu03umy-ashish-bind.vercel.app/)
